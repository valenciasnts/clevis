package hk.edu.polyu.comp.comp2021.clevis.model;

import org.junit.Test;

public class ClevisTest {

    @Test
    public void testClevisConstructor(){
        Clevis clevis = new Clevis();
        assert true;
    }
	
}